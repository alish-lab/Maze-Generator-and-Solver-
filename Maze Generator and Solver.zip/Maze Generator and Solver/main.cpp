#include <SFML/Graphics.hpp>
#include <vector>
#include <stack>
#include <random>
#include <chrono>
#include <string>
#include <queue>
#include <iostream>
using namespace std;

class Button {
private:
    sf::RectangleShape shape;
    sf::Text text;
    bool isPressed = false;

public:
    Button(const sf::Font& font, const std::string& buttonText, const sf::Vector2f& position, const sf::Vector2f& size) {
        shape.setPosition(position);
        shape.setSize(size);
        shape.setFillColor(sf::Color(70, 70, 70));
        shape.setOutlineColor(sf::Color::White);
        shape.setOutlineThickness(2);

        text.setFont(font);
        text.setString(buttonText);
        text.setCharacterSize(20);
        text.setFillColor(sf::Color::White);

        // Center text in button
        sf::FloatRect textBounds = text.getLocalBounds();
        text.setPosition(
            position.x + (size.x - textBounds.width) / 2,
            position.y + (size.y - textBounds.height - 5) / 2
        );
    }

    void draw(sf::RenderWindow& window) {
        window.draw(shape);
        window.draw(text);
    }

    bool isMouseOver(const sf::Vector2f& mousePos) {
        return shape.getGlobalBounds().contains(mousePos);
    }

    void setPressed(bool pressed) {
        isPressed = pressed;
        shape.setFillColor(pressed ? sf::Color(100, 100, 100) : sf::Color(70, 70, 70));
    }
};
class Text {
private:
    sf::Text text;

public:
    Text(const sf::Font& font, const std::string& labelText, const sf::Vector2f& position) {
        text.setFont(font);
        text.setString(labelText);
        text.setPosition(position);
        text.setCharacterSize(18);
        text.setFillColor(sf::Color::Blue);
        text.setOutlineThickness(0.5);
        text.setOutlineColor(sf::Color::White);
    }
    void draw(sf::RenderWindow& window) {
        window.draw(text);
    }
};
class InputField {
private:
    sf::RectangleShape shape;
    sf::Text text;
    sf::Text label;
    std::string value = "0";
    sf::Text errorMessage;
    bool isSelected = false;
    bool hasError = false;
    pair<int, int> current;

public:
    InputField(const sf::Font& font, const std::string& labelText, const sf::Vector2f& position) {
        shape.setPosition(position);
        shape.setSize(sf::Vector2f(60, 30));
        shape.setFillColor(sf::Color::White);
        shape.setOutlineColor(sf::Color::Black);
        shape.setOutlineThickness(2);

        text.setFont(font);
        text.setString(value);
        text.setCharacterSize(20);
        text.setFillColor(sf::Color::Black);
        text.setPosition(position.x + 5, position.y + 5);

        label.setFont(font);
        label.setString(labelText);
        label.setCharacterSize(20);
        label.setFillColor(sf::Color::White);
        label.setPosition(position.x, position.y - 25);

        errorMessage.setFont(font);
        errorMessage.setString("");
        errorMessage.setCharacterSize(18);
        errorMessage.setFillColor(sf::Color::Red);
        errorMessage.setPosition(position.x, 60);  // Adjust as needed
    }

    void draw(sf::RenderWindow& window) {
        window.draw(shape);
        window.draw(text);
        window.draw(label);
        if (hasError) {  // Only draw the error message if there is an error
            window.draw(errorMessage);
        }
    }

    bool isMouseOver(const sf::Vector2f& mousePos) {
        return shape.getGlobalBounds().contains(mousePos);
    }

    void setSelected(bool selected) {
        isSelected = selected;
        shape.setOutlineColor(selected ? sf::Color::Blue : sf::Color::Black);
    }

    void handleInput(char c) {
        if (isSelected) {
            if (c >= '0' && c <= '9' && value.length() < 3) {
                value += c;
            }
            text.setString(value);
        }
    }

    void handleBackspace() {
        if (isSelected && !value.empty()) {
            value.pop_back();
            text.setString(value);
        }
    }

    int getValue() const {
        return std::stoi(value.empty() ? "0" : value);
    }
    void validateInput() {
        int intValue = getValue();
        if (intValue > 35) {
            hasError = true;
            errorMessage.setString("Rows must be <= 35");
        }
        else if (intValue > 25) {
            hasError = true;
            errorMessage.setString("Columns must be <= 54");
        }
        else {
            hasError = false;
            errorMessage.setString("");
        }
    }
};

class Cell {
public:
    bool walls[4] = { true, true, true, true }; // top, right, bottom, left
    bool visited = false;
};

class Maze {
private:
    struct FrontierCell {
        int row, col;
        FrontierCell(int r, int c) : row(r), col(c) {}
    };
    std::vector<std::vector<Cell>> grid;
    int rows, cols;
    int cellSize;
    pair<int, int> current;

    std::mt19937 rng;
    std::pair<int, int> start, end;
    vector<pair<int, int>> path;
    bool isGenerating = false;
    bool isSolving = false;
    bool isComplete = false;

    string currentAlgorithm = "PRIM";

    std::vector<std::pair<int, int>> directions = {
        {-1, 0}, {0, 1}, {1, 0}, {0, -1}  // Top, Right, Bottom, Left
    };

    // DFS-specific
    std::stack<std::pair<int, int>> dfsStack;

    // Prim's-specific
    std::vector<FrontierCell> frontier;

    void shuffleDirections() {
        std::shuffle(directions.begin(), directions.end(), rng);
    }

    void addFrontierCells(int row, int col) {
        for (const auto& dir : directions) {
            int newRow = row + dir.first;
            int newCol = col + dir.second;
            if (newRow >= 0 && newRow < rows && newCol >= 0 && newCol < cols &&
                !grid[newRow][newCol].visited) {
                bool alreadyInFrontier = false;
                // Check if the cell is already in the frontier
                for (const auto& frontierCell : frontier) {
                    if (frontierCell.row == newRow && frontierCell.col == newCol) {
                        alreadyInFrontier = true;
                        break;
                    }
                }
                if (!alreadyInFrontier) {
                    frontier.emplace_back(newRow, newCol);
                    current = { newRow, newCol };
                }
            }
        }
    }

    bool DFSGenerateStep() {
        if (dfsStack.empty()) {
            isComplete = true;
            isGenerating = false;
            return false;
        }

        current = dfsStack.top();
        int row = current.first;
        int col = current.second;
        dfsStack.pop();

        shuffleDirections();

        for (const auto& dir : directions) {
            int newRow = row + dir.first;
            int newCol = col + dir.second;

            if (newRow >= 0 && newRow < rows && newCol >= 0 && newCol < cols &&
                !grid[newRow][newCol].visited) {
                grid[newRow][newCol].visited = true;
                removeWalls(row, col, newRow, newCol);
                dfsStack.push({ row, col });
                dfsStack.push({ newRow, newCol });
                return true;
            }
        }
        return true;
    }

    bool PrimGenerateStep() {
        if (frontier.empty()) {
            isComplete = true;
            isGenerating = false;
            return false;
        }

        std::uniform_int_distribution<int> dist(0, frontier.size() - 1);
        int randomIndex = dist(rng);
        FrontierCell currentCell = frontier[randomIndex];
        frontier.erase(frontier.begin() + randomIndex);

        std::vector<std::pair<int, int>> neighbors;
        for (const auto& dir : directions) {
            int newRow = currentCell.row + dir.first;
            int newCol = currentCell.col + dir.second;

            if (newRow >= 0 && newRow < rows && newCol >= 0 && newCol < cols &&
                grid[newRow][newCol].visited) {
                neighbors.emplace_back(newRow, newCol);
            }
        }

        if (!neighbors.empty()) {
            std::uniform_int_distribution<int> neighborDist(0, neighbors.size() - 1);
            std::pair<int, int> selectedNeighbor = neighbors[neighborDist(rng)];
            int nRow = selectedNeighbor.first;
            int nCol = selectedNeighbor.second;
            removeWalls(currentCell.row, currentCell.col, nRow, nCol);
        }

        grid[currentCell.row][currentCell.col].visited = true;
        addFrontierCells(currentCell.row, currentCell.col);

        return true;
    }

    

    void removeWalls(int row1, int col1, int row2, int col2) {
        int diffRow = row2 - row1;
        int diffCol = col2 - col1;

        if (diffRow == -1) {
            grid[row1][col1].walls[0] = false;
            grid[row2][col2].walls[2] = false;
        }
        else if (diffRow == 1) {
            grid[row1][col1].walls[2] = false;
            grid[row2][col2].walls[0] = false;
        }
        else if (diffCol == -1) {
            grid[row1][col1].walls[3] = false;
            grid[row2][col2].walls[1] = false;
        }
        else if (diffCol == 1) {
            grid[row1][col1].walls[1] = false;
            grid[row2][col2].walls[3] = false;
        }
    }

public:

    Maze(int r, int c, int size) : rows(r), cols(c), cellSize(size) 
    {
        start = { 0,0 };
        end = { rows - 1,cols -1 };
        

        reset();
        
    }

    void setGeneratingAlgorithm(string algo) {
        currentAlgorithm = algo;
        reset();
    }
        
    bool generated() {
        return isGenerating;
    }

    void setPoints(int a, int b, int c, int d) {
        start = { a-1,b-1 };
        end = { c - 1, d - 1 };
    }

   void reset() {
    path.clear();
    grid.clear();
    grid.resize(rows, std::vector<Cell>(cols));
    std::stack<std::pair<int, int>> emptyStack;
    std::swap(dfsStack, emptyStack);  // Clear the stack by swapping with an empty one.
    frontier.clear();

    rng.seed(std::chrono::steady_clock::now().time_since_epoch().count());

    int startRow = rng() % rows;
    int startCol = rng() % cols;

    grid[startRow][startCol].visited = true;

    if (currentAlgorithm == "DFS") {
        dfsStack.push({ startRow, startCol });
    }
    else if (currentAlgorithm == "PRIM") {
        addFrontierCells(startRow, startCol);
    }

    isGenerating = false;
    isComplete = false;
}


    void setDimensions(int r, int c) {
        rows = r;
        cols = c;
        reset();
    }

    bool generateStep() {
        if (!isGenerating) return false;

        if (currentAlgorithm == "DFS") {
            return DFSGenerateStep();
        }
        else if (currentAlgorithm == "PRIM") {
            return PrimGenerateStep();
        }

        return false;
    }

    void toggleGeneration() {
        isGenerating = !isGenerating;
    }

    void toggleSolving(){
        isSolving = !isSolving;
    }
    void reconstructPath(map < pair<int, int>, pair<int, int>>& parent) {
        path.clear();
        pair<int, int> current = end;

        while (current != start) {
            path.push_back(current);
            current = parent[current];

        }
        path.push_back(start);
        reverse(path.begin(), path.end());
    }

    bool solveMazeBFS() {
        if (!isSolving) return false;
        queue<pair<int, int>> queue;
        vector< vector< bool>> visited(rows, vector<bool>(cols, false));
        map< pair<int, int>, pair<int, int>> parent;

        queue.push(start);
        visited[start.first][start.second] = true;

        while (!queue.empty()) {
            auto current = queue.front();
            queue.pop();

            if (current == end) {
                reconstructPath(parent);
                isSolving = false;
                return true;
            }

            vector<pair<pair<int, int>, int>> neighbours = {
            {{current.first - 1, current.second}, 0}, // Up
            {{current.first, current.second + 1}, 1}, // Right
            {{current.first + 1, current.second}, 2}, // Down
            {{current.first, current.second - 1}, 3}  // Left
            };

            for (auto& neighbour : neighbours) {
                int row = neighbour.first.first;
                int col = neighbour.first.second;
                int direction = neighbour.second;

                if (row >= 0 && row < rows && col >= 0 && col < cols &&
                    !visited[row][col] && !grid[current.first][current.second].walls[direction]) {

                    queue.push(neighbour.first);
                    visited[row][col] = true;
                    parent[neighbour.first] = current;
                }
            }
        }

        return false;
    }


    void draw(sf::RenderWindow& window) {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                float x = j * cellSize + 10;
                float y = i * cellSize + 10;

                bool onPath = std::find(path.begin(), path.end(), std::make_pair(i, j)) != path.end();


                sf::RectangleShape cell(sf::Vector2f(cellSize, cellSize));
                cell.setPosition(x, y);

                
                if (onPath) {
                    cell.setFillColor(sf::Color::Red); // Highlight the path in green
                }
                else if (grid[i][j].visited) {
                    cell.setFillColor(sf::Color(137, 207, 240));
                    }
                else if (i == current.first && j == current.second && isGenerating) {
                    cell.setFillColor(sf::Color(0, 150, 255)); // Highlight the current cell during generation
                }
    
                else {
                    cell.setFillColor(sf::Color(50, 50, 100));
                }

                window.draw(cell);

                // Draw walls
                if (grid[i][j].walls[0]) {
                    sf::RectangleShape wall(sf::Vector2f(cellSize, 1.5));
                    wall.setPosition(x, y);
                    wall.setFillColor(sf::Color::Black);
                    window.draw(wall);
                }
                if (grid[i][j].walls[1]) {
                    sf::RectangleShape wall(sf::Vector2f(1.5, cellSize));
                    wall.setPosition(x + cellSize - 1.5, y);
                    wall.setFillColor(sf::Color::Black);
                    window.draw(wall);
                }
                if (grid[i][j].walls[2]) {
                    sf::RectangleShape wall(sf::Vector2f(cellSize, 1.5));
                    wall.setPosition(x, y + cellSize - 1.5);
                    wall.setFillColor(sf::Color::Black);
                    window.draw(wall);
                }
                if (grid[i][j].walls[3]) {
                    sf::RectangleShape wall(sf::Vector2f(1.5, cellSize));
                    wall.setPosition(x, y);
                    wall.setFillColor(sf::Color::Black);
                    window.draw(wall);
                }
            }
        }
    }
};

int main() {
    const int WINDOW_WIDTH = 1280;
    const int WINDOW_HEIGHT = 720;
    const int CELL_SIZE = 20;
    const int INITIAL_ROWS = 15;
    const int INITIAL_COLS = 15;
    const int UI_WIDTH = 200;
    int rows = INITIAL_ROWS;
    int cols = INITIAL_COLS;
    int startX = 0, startY = 0, endX = 0, endY= 0;

    sf::RenderWindow window(
        sf::VideoMode(WINDOW_WIDTH, WINDOW_HEIGHT), 
        "Maze Generator",
        sf::Style::Close | sf::Style::Titlebar
    );
    window.setFramerateLimit(30);

    // Load font
    sf::Font font;
    if (!font.loadFromFile("arial.ttf")) {
        // If arial.ttf is not available, you might need to provide your own font file
        return -1;
    }

    Maze maze(INITIAL_ROWS, INITIAL_COLS, CELL_SIZE);

    // Create UI elements
    vector<Button> buttons;
    float buttonX = WINDOW_WIDTH - 180; //INITIAL_COLS * CELL_SIZE + 20
    buttons.push_back(Button(font, "Start/Stop", sf::Vector2f(buttonX, 160), sf::Vector2f(160, 40)));
    buttons.push_back(Button(font, "Reset", sf::Vector2f(buttonX, WINDOW_HEIGHT-50), sf::Vector2f(160, 40)));
    buttons.push_back(Button(font, "Solve", sf::Vector2f(buttonX, 580), sf::Vector2f(160, 40)));
    buttons.push_back(Button(font, "Apply Size", sf::Vector2f(buttonX, 340), sf::Vector2f(160, 40)));
    buttons.push_back(Button(font, "Apply Points", sf::Vector2f(buttonX, 520), sf::Vector2f(160, 40)));
    buttons.push_back(Button(font, "DFS", sf::Vector2f(buttonX, 100), sf::Vector2f(75, 40)));
    buttons.push_back(Button(font, "PRIMS ", sf::Vector2f(buttonX + 85, 100), sf::Vector2f(75, 40)));

    std::vector<InputField> inputs;
    inputs.push_back(InputField(font, "Rows:", sf::Vector2f(buttonX, 240)));
    inputs.push_back(InputField(font, "Columns:", sf::Vector2f(buttonX, 300)));
    inputs.push_back((InputField(font, "Start X:", sf::Vector2f(buttonX, 420))));
    inputs.push_back((InputField(font, "Start Y:", sf::Vector2f(buttonX + 80, 420))));
    inputs.push_back((InputField(font, "End X:", sf::Vector2f(buttonX, 480))));
    inputs.push_back((InputField(font, "End Y:", sf::Vector2f(buttonX + 80, 480))));

    vector<Text> title;
    title.push_back(Text(font, "MAZE GENERATOR\n      AND SOLVER", sf::Vector2f(buttonX, 10)));

    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                window.close();
            }
            else if (event.type == sf::Event::MouseButtonPressed) {
                sf::Vector2f mousePos = window.mapPixelToCoords(sf::Mouse::getPosition(window));

                // Handle button clicks
                for (size_t i = 0; i < buttons.size(); i++) {
                    
                    if (buttons[i].isMouseOver(mousePos)) {
                        buttons[i].setPressed(true);
                        
                        
                        
                        if (i == 0) maze.toggleGeneration();
                        if (i == 1) maze.reset();
                        if (i == 2) maze.toggleSolving();
                        if (i == 3) {
                            rows = inputs[0].getValue();
                            cols = inputs[1].getValue();
                            
                            if(rows > 0 && rows <= 35 && cols > 0 && cols <= 54) {
                                maze.setDimensions(rows, cols);
                            }
                            for (auto& input : inputs) {
                                input.validateInput();
                            }
                        }
                        if (i == 4) {
                            startX = inputs[2].getValue();
                            startY = inputs[3].getValue();
                            endX = inputs[4].getValue();
                            endY = inputs[5].getValue();
                            
                            if (startX > 0 && startX <= cols && startY > 0 && startY <= rows &&
                                endX > 0 && endX <= cols && endY > 0 && endY <= rows) {
                                cout << "Start: (" << startX << ", " << startY << "), End: ("
                                    << endX << ", " << endY << ")" << std::endl;
                                maze.setPoints(startY, startX, endY, endX);
                            }
                            else {
                                for (auto& input : inputs) {
                                    input.validateInput();
                                }
                                cout << "Invalid start or end points." << std::endl;
                            }

                        }
                        if (i == 5) {
                            maze.setGeneratingAlgorithm("DFS");
                            

                        }
                        if (i == 6) {
                            maze.setGeneratingAlgorithm("PRIM");
                            
                        }
                    }
                }

                // Handle input field selection
                for (auto& input : inputs) {
                    input.setSelected(input.isMouseOver(mousePos));
                }
            }
            else if (event.type == sf::Event::MouseButtonReleased) {
                for (auto& button : buttons) {
                    button.setPressed(false);
                }
            }
            else if (event.type == sf::Event::TextEntered) {
                char enteredChar = static_cast<char>(event.text.unicode);
                for (auto& input : inputs) {
                    if (event.text.unicode < 128) {
                        input.handleInput(static_cast<char>(event.text.unicode));
                    }
                }
            }
            else if (event.type == sf::Event::KeyPressed) {
                if (event.key.code == sf::Keyboard::BackSpace) {
                    for (auto& input : inputs) {
                        input.handleBackspace();
                    }
                }
                else if (event.key.code == sf::Keyboard::Return) {
                    
                    

                    
                }
            }
        }

        maze.generateStep();
        maze.solveMazeBFS();
        window.setFramerateLimit(60);
        

        window.clear(sf::Color(32,32,32, 256));
        sf::RectangleShape panel(sf::Vector2f(UI_WIDTH, WINDOW_HEIGHT));
        panel.setFillColor(sf::Color(12, 12, 12)); // Dark grey panel background
        panel.setPosition(WINDOW_WIDTH - UI_WIDTH, 0);
        window.draw(panel);
        maze.draw(window);

        // Draw UI
        for (auto& button : buttons) {
            button.draw(window);
        }
        for (auto& input : inputs) {
            input.draw(window);
        }
        for (auto& text : title) {
            text.draw(window);
        }

        window.display();
    }

    return 0;
}



